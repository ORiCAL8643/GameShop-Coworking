import React, { useEffect, useState } from 'react'
import { Table, Button, Input } from 'antd'
import axios from 'axios'

function App() {
  const [products, setProducts] = useState<any[]>([])
  const [title, setTitle] = useState('')
  const [price, setPrice] = useState('')

  useEffect(() => {
    axios.get('/api/products').then(res => setProducts(res.data))
  }, [])

  const addProduct = async () => {
    const res = await axios.post('/api/products', { title, price: parseFloat(price) })
    setProducts([...products, res.data])
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Game Store</h1>
      <Input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <Input placeholder="Price" value={price} onChange={e => setPrice(e.target.value)} />
      <Button type="primary" onClick={addProduct}>Add Product</Button>
      <Table dataSource={products} rowKey="id" columns={[{title:'Title', dataIndex:'title'}, {title:'Price', dataIndex:'price'}]} />
    </div>
  )
}

export default App
