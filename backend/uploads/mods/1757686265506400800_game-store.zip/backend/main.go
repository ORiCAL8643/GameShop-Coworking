package main

import (
    "game-store/routes"
    "game-store/entity"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "log"
)

func main() {
    db, err := gorm.Open(sqlite.Open("app.db"), &gorm.Config{})
    if err != nil {
        log.Fatal("failed to connect database")
    }

    // Auto migrate entities
    db.AutoMigrate(&entity.User{}, &entity.Product{})

    r := routes.SetupRouter(db)
    r.Run(":8080")
}
