package routes

import (
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "net/http"
    "game-store/entity"
)

func SetupRouter(db *gorm.DB) *gin.Engine {
    r := gin.Default()

    r.GET("/api/products", func(c *gin.Context) {
        var products []entity.Product
        db.Find(&products)
        c.JSON(http.StatusOK, products)
    })

    r.POST("/api/products", func(c *gin.Context) {
        var p entity.Product
        if err := c.ShouldBindJSON(&p); err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
            return
        }
        db.Create(&p)
        c.JSON(http.StatusOK, p)
    })

    return r
}
