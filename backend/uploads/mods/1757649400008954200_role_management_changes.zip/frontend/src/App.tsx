import { Layout } from 'antd';
import Sidebar from './components/Sidebar';
import Home from './pages/Home';

const App = () => {
  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sidebar />
      <Home />
    </Layout>
  );
};

export default App;
