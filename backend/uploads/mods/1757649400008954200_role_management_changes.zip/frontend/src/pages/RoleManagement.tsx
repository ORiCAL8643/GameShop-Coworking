
import React from "react";
import { Button, Input, Table, Typography, Space, Card } from "antd";
import {
  UserOutlined,
  EditOutlined,
  MoreOutlined,
  TeamOutlined,
} from "@ant-design/icons";
import Navbar from "../components/Navbar";

const { Title } = Typography;

const RoleManagement: React.FC = () => {
  const columns = [
    {
      title: "บทบาท",
      dataIndex: "role",
      key: "role",
      render: (text: string, record: any) => (
        <Space>
          {record.icon}
          {text}
        </Space>
      ),
    },
    {
      title: "สมาชิก",
      dataIndex: "members",
      key: "members",
      render: (count: number) => (
        <Space>
          <UserOutlined />
          {count}
        </Space>
      ),
    },
    {
      title: "",
      key: "actions",
      render: () => (
        <Space>
          <Button
            shape="circle"
            icon={<EditOutlined />}
            style={{ border: "none" }}
          />
          <Button
            shape="circle"
            icon={<MoreOutlined />}
            style={{ border: "none" }}
          />
        </Space>
      ),
    },
  ];

  const data = [
    {
      key: "1",
      role: "Admin",
      members: 1,
      icon: <TeamOutlined style={{ color: "#1890ff" }} />,
    },
    {
      key: "2",
      role: "Customer",
      members: 0,
      icon: <TeamOutlined style={{ color: "#52c41a" }} />,
    },
  ];

  return (
    <div style={{ background: "#141414", minHeight: "100vh" }}>
      <Navbar />
      <div style={{ padding: 16 }}>
        <Title level={3} style={{ color: "white" }}>
          บทบาท
        </Title>

        <Card
          style={{
            background: "#1f1f1f",
            color: "white",
            marginBottom: 16,
            borderRadius: 8,
          }}
        >
          <Space style={{ color: "white" }}>
            <UserOutlined />
            การอนุญาตตั้งต้น @everyone - มีผลกับสมาชิกทุกคนในเซิร์ฟเวอร์
          </Space>
        </Card>

        <Space style={{ marginBottom: 16 }}>
          <Input.Search placeholder="ค้นหาบทบาท" style={{ width: 200 }} />
          <Button type="primary" shape="round">
            สร้างบทบาทใหม่
          </Button>
        </Space>

        <Table
          columns={columns}
          dataSource={data}
          pagination={false}
          style={{
            background: "#1f1f1f",
            borderRadius: 8,
            overflow: "hidden",
          }}
        />
      </div>
    </div>
  );
};

export default RoleManagement;
