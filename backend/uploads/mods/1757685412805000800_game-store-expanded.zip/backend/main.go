package main

import (
    "game-store-backend/routes"
    "game-store-backend/entity"
    "game-store-backend/seed"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "log"
)

func main() {
    db, err := gorm.Open(sqlite.Open("app.db"), &gorm.Config{})
    if err != nil {
        log.Fatal("failed to connect database: ", err)
    }

    // Auto migrate entities
    db.AutoMigrate(&entity.User{}, &entity.Product{}, &entity.Request{}, &entity.WorkshopItem{}, &entity.Order{}, &entity.OrderItem{}, &entity.Payment{}, &entity.Promotion{}, &entity.Refund{}, &entity.Post{}, &entity.Comment{}, &entity.Review{}, &entity.Report{})

    // Seed sample data
    seed.Seed(db)

    r := routes.SetupRouter(db)
    log.Println("Backend running on http://localhost:8080")
    r.Run(":8080")
}
