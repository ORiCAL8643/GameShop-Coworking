package routes

import (
    "github.com/gin-contrib/cors"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/controllers"
    "game-store-backend/middleware"
)

func SetupRouter(db *gorm.DB) *gin.Engine {
    r := gin.Default()
    r.Use(cors.Default())
    r.Use(middleware.MockAuth())

    pc := &controllers.ProductController{DB: db}
    rc := &controllers.RequestController{DB: db}
    wc := &controllers.WorkshopController{DB: db}
    oc := &controllers.OrderController{DB: db}
    payc := &controllers.PaymentController{DB: db}
    promc := &controllers.PromotionController{DB: db}
    refc := &controllers.RefundController{DB: db}
    cc := &controllers.CommunityController{DB: db}
    revc := &controllers.ReviewController{DB: db}
    repc := &controllers.ReportController{DB: db}

    api := r.Group("/api")
    {
        api.POST("/auth/login", controllers.Login)
        pr := api.Group("/products")
        { pr.GET("/", pc.List); pr.GET(":id", pc.Get); pr.POST("/", middleware.RequireRole("admin"), pc.Create) }

        req := api.Group("/requests")
        { req.POST("/", rc.Create); req.GET("/", middleware.RequireRole("admin"), rc.List); req.PUT(":id/status", middleware.RequireRole("admin"), rc.UpdateStatus) }

        wk := api.Group("/workshop")
        { wk.POST("/", wc.Create); wk.GET("/", wc.List) }

        ord := api.Group("/orders")
        { ord.POST("/", oc.Create); ord.GET(":id", oc.Get) }

        pay := api.Group("/payments")
        { pay.POST("/mock", payc.MockPay) }

        promo := api.Group("/promotions")
        { promo.POST("/", middleware.RequireRole("admin"), promc.Create); promo.GET("/", promc.List) }

        refund := api.Group("/refunds")
        { refund.POST("/", refc.Create); refund.GET("/", middleware.RequireRole("admin"), refc.List) }

        comm := api.Group("/community")
        { comm.POST("/posts", cc.CreatePost); comm.GET("/posts", cc.ListPosts); comm.POST("/comments", cc.AddComment) }

        rev := api.Group("/reviews")
        { rev.POST("/", revc.Create); rev.GET("/product/:productId", revc.ListForProduct) }

        rep := api.Group("/reports")
        { rep.POST("/", repc.Create); rep.GET("/", middleware.RequireRole("admin"), repc.List) }
    }

    return r
}
