package middleware

import (
    "github.com/gin-gonic/gin"
)

// Mock middleware: reads header X-User-Email and X-User-Role if present
func MockAuth() gin.HandlerFunc {
    return func(c *gin.Context) {
        email := c.GetHeader("X-User-Email")
        role := c.GetHeader("X-User-Role")
        if email != "" {
            c.Set("userEmail", email)
            c.Set("userRole", role)
        }
        c.Next()
    }
}

func RequireRole(roles ...string) gin.HandlerFunc {
    return func(c *gin.Context) {
        v, exists := c.Get("userRole")
        if !exists {
            c.AbortWithStatusJSON(401, gin.H{"error":"unauthorized"})
            return
        }
        role := v.(string)
        for _, r := range roles {
            if r == role {
                c.Next()
                return
            }
        }
        c.AbortWithStatusJSON(403, gin.H{"error":"forbidden"})
    }
}
