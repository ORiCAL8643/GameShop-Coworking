package seed

import (
    "game-store-backend/entity"
    "gorm.io/gorm"
)

func Seed(db *gorm.DB) {
    // seed users
    db.Where(entity.User{Email: "admin@example.com"}).Attrs(entity.User{Name: "Admin", Role: "admin"}).FirstOrCreate(&entity.User{})
    db.Where(entity.User{Email: "user@example.com"}).Attrs(entity.User{Name: "Demo User", Role: "user"}).FirstOrCreate(&entity.User{})

    // seed products
    var count int64
    db.Model(&entity.Product{}).Count(&count)
    if count == 0 {
        products := []entity.Product{
            {Title: "Elden Ring", Slug: "elden-ring", Description: "Action RPG", Price: 59.99, ImageURL: "https://placehold.co/600x400?text=Elden+Ring", Platform: "PC", Stock: 20},
            {Title: "Baldur's Gate 3", Slug: "baldurs-gate-3", Description: "CRPG", Price: 69.99, ImageURL: "https://placehold.co/600x400?text=BG3", Platform: "PC", Stock: 15},
            {Title: "God of War", Slug: "god-of-war", Description: "Action Adventure", Price: 49.99, ImageURL: "https://placehold.co/600x400?text=GOW", Platform: "PS5", Stock: 10},
        }
        for _, p := range products {
            db.Create(&p)
        }
    }

    // seed a promotion
    db.Where(entity.Promotion{Code: "WELCOME10"}).Attrs(entity.Promotion{DiscountPercent: 10, Active: true}).FirstOrCreate(&entity.Promotion{})
}
