package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type RequestController struct{ DB *gorm.DB }

func (rc *RequestController) Create(c *gin.Context){
    var r entity.Request
    if err := c.ShouldBindJSON(&r); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    r.Status = "pending"
    rc.DB.Create(&r)
    c.JSON(http.StatusCreated, r)
}

func (rc *RequestController) List(c *gin.Context){
    var list []entity.Request
    rc.DB.Find(&list)
    c.JSON(http.StatusOK, list)
}

func (rc *RequestController) UpdateStatus(c *gin.Context){
    id := c.Param("id")
    var r entity.Request
    if err := rc.DB.First(&r, id).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error":"not found"})
        return
    }
    var body struct{ Status string `json:"status"` }
    if err := c.ShouldBindJSON(&body); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    r.Status = body.Status
    rc.DB.Save(&r)
    c.JSON(http.StatusOK, r)
}
