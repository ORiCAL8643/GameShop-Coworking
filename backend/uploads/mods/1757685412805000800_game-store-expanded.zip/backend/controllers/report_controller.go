package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type ReportController struct{ DB *gorm.DB }

func (rc *ReportController) Create(c *gin.Context){
    var r entity.Report
    if err := c.ShouldBindJSON(&r); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    r.Status = "open"
    rc.DB.Create(&r)
    c.JSON(http.StatusCreated, r)
}

func (rc *ReportController) List(c *gin.Context){
    var list []entity.Report
    rc.DB.Find(&list)
    c.JSON(http.StatusOK, list)
}
