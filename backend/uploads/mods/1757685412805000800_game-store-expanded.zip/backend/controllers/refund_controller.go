package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type RefundController struct{ DB *gorm.DB }

func (rc *RefundController) Create(c *gin.Context){
    var r entity.Refund
    if err := c.ShouldBindJSON(&r); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    r.Status = "requested"
    rc.DB.Create(&r)
    c.JSON(http.StatusCreated, r)
}

func (rc *RefundController) List(c *gin.Context){
    var list []entity.Refund
    rc.DB.Find(&list)
    c.JSON(http.StatusOK, list)
}
