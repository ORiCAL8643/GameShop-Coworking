package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type PromotionController struct{ DB *gorm.DB }

func (pc *PromotionController) Create(c *gin.Context){
    var p entity.Promotion
    if err := c.ShouldBindJSON(&p); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    pc.DB.Create(&p)
    c.JSON(http.StatusCreated, p)
}

func (pc *PromotionController) List(c *gin.Context){
    var list []entity.Promotion
    pc.DB.Find(&list)
    c.JSON(http.StatusOK, list)
}
