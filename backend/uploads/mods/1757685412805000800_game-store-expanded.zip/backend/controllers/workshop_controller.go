package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type WorkshopController struct{ DB *gorm.DB }

func (wc *WorkshopController) Create(c *gin.Context){
    var w entity.WorkshopItem
    if err := c.ShouldBindJSON(&w); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    wc.DB.Create(&w)
    c.JSON(http.StatusCreated, w)
}

func (wc *WorkshopController) List(c *gin.Context){
    var list []entity.WorkshopItem
    wc.DB.Find(&list)
    c.JSON(http.StatusOK, list)
}
