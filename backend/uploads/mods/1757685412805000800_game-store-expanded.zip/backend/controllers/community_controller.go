package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type CommunityController struct{ DB *gorm.DB }

func (cc *CommunityController) CreatePost(c *gin.Context){
    var p entity.Post
    if err := c.ShouldBindJSON(&p); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    cc.DB.Create(&p)
    c.JSON(http.StatusCreated, p)
}

func (cc *CommunityController) ListPosts(c *gin.Context){
    var list []entity.Post
    cc.DB.Preload("Comments").Find(&list)
    c.JSON(http.StatusOK, list)
}

func (cc *CommunityController) AddComment(c *gin.Context){
    var cm entity.Comment
    if err := c.ShouldBindJSON(&cm); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    cc.DB.Create(&cm)
    c.JSON(http.StatusCreated, cm)
}
