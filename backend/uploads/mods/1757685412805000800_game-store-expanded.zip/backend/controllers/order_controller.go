package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type OrderController struct{ DB *gorm.DB }

type CreateOrderReq struct{
    UserEmail string `json:"userEmail"`
    Items []struct{ ProductID uint `json:"productId"`; Quantity int `json:"quantity"` } `json:"items"`
    PromotionCode string `json:"promotionCode"`
}

func (oc *OrderController) Create(c *gin.Context){
    var req CreateOrderReq
    if err := c.ShouldBindJSON(&req); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }

    var items []entity.OrderItem
    var total float64
    for _, it := range req.Items{
        var p entity.Product
        if err := oc.DB.First(&p, it.ProductID).Error; err != nil { c.JSON(http.StatusBadRequest, gin.H{"error":"invalid product"}); return }
        if p.Stock < it.Quantity { c.JSON(http.StatusBadRequest, gin.H{"error":"insufficient stock"}); return }
        p.Stock -= it.Quantity
        oc.DB.Save(&p)
        items = append(items, entity.OrderItem{ProductID: p.ID, Title: p.Title, Price: p.Price, Quantity: it.Quantity})
        total += p.Price * float64(it.Quantity)
    }
    // apply promotion mock
    if req.PromotionCode != "" {
        var promo entity.Promotion
        if err := oc.DB.Where("code = ? AND active = ?", req.PromotionCode, true).First(&promo).Error; err == nil {
            total = total * (100 - float64(promo.DiscountPercent)) / 100
        }
    }
    order := entity.Order{UserEmail: req.UserEmail, Status: "pending", Total: total, Items: items}
    oc.DB.Create(&order)
    c.JSON(http.StatusCreated, order)
}

func (oc *OrderController) Get(c *gin.Context){
    id := c.Param("id")
    var ord entity.Order
    if err := oc.DB.Preload("Items").First(&ord, id).Error; err != nil { c.JSON(http.StatusNotFound, gin.H{"error":"not found"}); return }
    c.JSON(http.StatusOK, ord)
}
