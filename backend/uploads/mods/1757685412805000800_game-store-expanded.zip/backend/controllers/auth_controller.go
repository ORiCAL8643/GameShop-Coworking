package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
)

// Mock login: accept any email and role (for dev)
func Login(c *gin.Context){
    var body struct{ Email string `json:"email"`; Role string `json:"role"` }
    if err := c.ShouldBindJSON(&body); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    // return token (in prod implement JWT)
    c.JSON(http.StatusOK, gin.H{"token":"demo-token","email": body.Email, "role": body.Role})
}
