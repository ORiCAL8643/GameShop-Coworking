package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type ProductController struct{ DB *gorm.DB }

func (pc *ProductController) List(c *gin.Context){
    var items []entity.Product
    pc.DB.Find(&items)
    c.JSON(http.StatusOK, items)
}

func (pc *ProductController) Get(c *gin.Context){
    id := c.Param("id")
    var p entity.Product
    if err := pc.DB.First(&p, id).Error; err != nil {
        c.JSON(http.StatusNotFound, gin.H{"error":"not found"})
        return
    }
    c.JSON(http.StatusOK, p)
}

func (pc *ProductController) Create(c *gin.Context){
    var p entity.Product
    if err := c.ShouldBindJSON(&p); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    pc.DB.Create(&p)
    c.JSON(http.StatusCreated, p)
}
