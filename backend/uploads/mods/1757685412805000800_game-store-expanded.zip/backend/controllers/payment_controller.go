package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type PaymentController struct{ DB *gorm.DB }

func (pc *PaymentController) MockPay(c *gin.Context){
    var body struct{ OrderID uint `json:"orderId"` }
    if err := c.ShouldBindJSON(&body); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    pay := entity.Payment{OrderID: body.OrderID, Amount: 0, Provider: "mock", Status: "succeeded"}
    pc.DB.Create(&pay)
    // mark order paid
    var o entity.Order
    if err := pc.DB.First(&o, body.OrderID).Error; err == nil { o.Status = "paid"; pc.DB.Save(&o) }
    c.JSON(http.StatusOK, pay)
}
