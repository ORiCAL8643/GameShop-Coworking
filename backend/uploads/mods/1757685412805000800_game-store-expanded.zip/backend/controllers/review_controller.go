package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

type ReviewController struct{ DB *gorm.DB }

func (rc *ReviewController) Create(c *gin.Context){
    var r entity.Review
    if err := c.ShouldBindJSON(&r); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()}); return }
    rc.DB.Create(&r)
    c.JSON(http.StatusCreated, r)
}

func (rc *ReviewController) ListForProduct(c *gin.Context){
    pid := c.Param("productId")
    var list []entity.Review
    rc.DB.Where("product_id = ?", pid).Find(&list)
    c.JSON(http.StatusOK, list)
}
