package entity

import "gorm.io/gorm"

type Report struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    Category  string `json:"category"`
    Message   string `json:"message"`
    Status    string `json:"status"` // open, in_progress, resolved
}
