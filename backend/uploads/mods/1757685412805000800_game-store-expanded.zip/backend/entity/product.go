package entity

import "gorm.io/gorm"

type Product struct {
    gorm.Model
    Title       string  `json:"title"`
    Slug        string  `gorm:"slug" gorm:"uniqueIndex"`
    Description string  `json:"description"`
    Price       float64 `json:"price"`
    ImageURL    string  `json:"imageUrl"`
    Platform    string  `json:"platform"`
    Stock       int     `json:"stock"`
}
