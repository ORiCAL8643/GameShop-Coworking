package entity

import "gorm.io/gorm"

type Refund struct {
    gorm.Model
    OrderID uint   `json:"orderId"`
    Reason  string `json:"reason"`
    Status  string `json:"status"` // requested, approved, rejected, processed
}
