package entity

import "gorm.io/gorm"

type Request struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    GameName  string `json:"gameName"`
    Reason    string `json:"reason"`
    Status    string `json:"status"` // pending, accepted, rejected
}
