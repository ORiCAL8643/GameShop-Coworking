package entity

import "gorm.io/gorm"

type Order struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    Status    string `json:"status"` // pending, paid, refunded
    Total     float64 `json:"total"`
    Items     []OrderItem `json:"items" gorm:"foreignKey:OrderID"`
}

type OrderItem struct {
    gorm.Model
    OrderID   uint   `json:"orderId"`
    ProductID uint   `json:"productId"`
    Title     string `json:"title"`
    Price     float64 `json:"price"`
    Quantity  int    `json:"quantity"`
}
