
import React from 'react'
import { createReview, fetchReviews } from '../api/client'
import { Form, InputNumber, Input, Button, List } from 'antd'

export default function Reviews(){
  const [list, setList] = React.useState<any[]>([])
  const [pid, setPid] = React.useState(1)
  React.useEffect(()=>{ fetchReviews(pid).then(d=>setList(d)) },[pid])
  const onFinish = async (vals:any)=>{ await createReview({productId:pid, userEmail:vals.email, rating:vals.rating, comment:vals.comment}); fetchReviews(pid).then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="inline">
        <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
        <Form.Item name="rating"><InputNumber min={1} max={5} defaultValue={5} /></Form.Item>
        <Form.Item name="comment"><Input placeholder="Comment"/></Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Review</Button></Form.Item>
      </Form>
      <List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.UserEmail}: {i.Rating} — {i.Comment}</List.Item>)} />
    </div>
  )
}
