
import React from 'react'
import { fetchProducts, createProduct } from '../api/client'
import { Table, Button, Modal, Form, Input, InputNumber } from 'antd'

export default function ManageGames(){
  const [list, setList] = React.useState<any[]>([])
  const [open, setOpen] = React.useState(false)
  React.useEffect(()=>{ fetchProducts().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createProduct({Title:vals.title, Price:vals.price, Slug:vals.slug, Description:vals.description, ImageURL:vals.image}); setOpen(false); fetchProducts().then(d=>setList(d)) }
  return (
    <div>
      <Button type="primary" onClick={()=>setOpen(true)}>Add Game</Button>
      <Table dataSource={list} rowKey="ID" style={{marginTop:16}} columns={[{title:'Title', dataIndex:'Title'},{title:'Price', dataIndex:'Price'}]} />
      <Modal open={open} onCancel={()=>setOpen(false)} footer={null}>
        <Form onFinish={onFinish} layout="vertical">
          <Form.Item name="title" label="Title" rules={[{required:true}]}><Input/></Form.Item>
          <Form.Item name="slug" label="Slug"><Input/></Form.Item>
          <Form.Item name="price" label="Price"><InputNumber/></Form.Item>
          <Form.Item name="description" label="Description"><Input.TextArea/></Form.Item>
          <Form.Item name="image" label="Image URL"><Input/></Form.Item>
          <Form.Item><Button htmlType="submit" type="primary">Create</Button></Form.Item>
        </Form>
      </Modal>
    </div>
  )
}
