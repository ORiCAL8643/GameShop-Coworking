
import React from 'react'
import { createReport, fetchReports } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Reports(){
  const [list, setList] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchReports().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createReport({userEmail:vals.email, category:vals.category, message:vals.message}); fetchReports().then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="vertical">
        <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
        <Form.Item name="category"> <Input placeholder="Category" /> </Form.Item>
        <Form.Item name="message"> <Input.TextArea placeholder="Message" /> </Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Report</Button></Form.Item>
      </Form>
      <List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.Category}: {i.Message}</List.Item>)} />
    </div>
  )
}
