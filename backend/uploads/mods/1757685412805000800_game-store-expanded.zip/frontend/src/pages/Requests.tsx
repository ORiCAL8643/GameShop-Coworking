
import React from 'react'
import { createRequest, fetchRequests } from '../api/client'
import { Form, Input, Button, Table, message } from 'antd'

export default function Requests(){
  const [list, setList] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchRequests().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createRequest({userEmail:vals.email, gameName:vals.game, reason:vals.reason}); message.success('Submitted'); fetchRequests().then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="inline">
        <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
        <Form.Item name="game" rules={[{required:true}]}> <Input placeholder="Game name" /> </Form.Item>
        <Form.Item name="reason"> <Input placeholder="Why?" /> </Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Request</Button></Form.Item>
      </Form>
      <Table dataSource={list} rowKey="ID" style={{marginTop:16}} columns={[{title:'Game', dataIndex:'GameName'}, {title:'Status', dataIndex:'Status'}, {title:'Email', dataIndex:'UserEmail'}]} />
    </div>
  )
}
