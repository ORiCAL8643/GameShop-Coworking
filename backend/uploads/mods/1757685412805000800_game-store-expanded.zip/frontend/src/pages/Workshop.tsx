
import React from 'react'
import { fetchWorkshop, createWorkshop } from '../api/client'
import { List, Form, Input, Button } from 'antd'

export default function Workshop(){
  const [list, setList] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchWorkshop().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createWorkshop({userEmail:vals.email, title:vals.title, description:vals.description, fileUrl:vals.file}); fetchWorkshop().then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="vertical">
        <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
        <Form.Item name="title" rules={[{required:true}]}> <Input placeholder="Title" /> </Form.Item>
        <Form.Item name="description"> <Input.TextArea placeholder="Description" /> </Form.Item>
        <Form.Item name="file"> <Input placeholder="File URL (mock)" /> </Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Upload</Button></Form.Item>
      </Form>
      <List dataSource={list} renderItem={item=> (<List.Item key={item.ID}><List.Item.Meta title={item.Title} description={item.Description} /></List.Item>)} />
    </div>
  )
}
