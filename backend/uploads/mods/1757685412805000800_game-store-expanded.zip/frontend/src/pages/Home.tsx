
import React from 'react'
import { fetchProducts } from '../api/client'
import { Row, Col, Card, Spin } from 'antd'

export default function Home(){
  const [loading, setLoading] = React.useState(true)
  const [products, setProducts] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchProducts().then(d=>setProducts(d)).finally(()=>setLoading(false)) },[])
  if(loading) return <Spin />
  return (
    <Row gutter={[16,16]}>
      {products.map(p=>(
        <Col key={p.ID} xs={24} sm={12} md={8} lg={6}>
          <Card title={p.Title}><img src={p.ImageURL} alt={p.Title} style={{width:'100%'}}/></Card>
        </Col>
      ))}
    </Row>
  )
}
