
import React from 'react'
import { createRefund } from '../api/client'
import { Form, Input, Button } from 'antd'

export default function Refunds(){
  const onFinish = async (vals:any)=>{ await createRefund({orderId:vals.orderId, reason:vals.reason}); alert('Requested') }
  return (
    <Form onFinish={onFinish} layout="vertical" style={{maxWidth:480}}>
      <Form.Item name="orderId" rules={[{required:true}]}><Input placeholder="Order ID"/></Form.Item>
      <Form.Item name="reason"><Input.TextArea placeholder="Reason"/></Form.Item>
      <Form.Item><Button htmlType="submit" type="primary">Request Refund</Button></Form.Item>
    </Form>
  )
}
