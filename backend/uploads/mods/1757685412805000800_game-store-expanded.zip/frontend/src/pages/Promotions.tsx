
import React from 'react'
import { createPromotion, fetchPromotions } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Promotions(){
  const [list, setList] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchPromotions().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createPromotion({Code:vals.code, DiscountPercent:vals.percent, Active:true}); fetchPromotions().then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="inline">
        <Form.Item name="code"><Input placeholder="Code"/></Form.Item>
        <Form.Item name="percent"><Input placeholder="Percent"/></Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Create</Button></Form.Item>
      </Form>
      <List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.Code} — {i.DiscountPercent}%</List.Item>)} />
    </div>
  )
}
