
import React from 'react'
import { createOrder, mockPay } from '../api/client'
import { Form, Input, Button } from 'antd'

export default function Payments(){
  const onFinish = async (vals:any)=>{
    const order = await createOrder({userEmail:vals.email, items: [{productId:1, quantity:1}], promotionCode: vals.promo||''})
    await mockPay({orderId:order.ID})
    alert('Order placed and paid. ID: '+order.ID)
  }
  return (
    <Form onFinish={onFinish} layout="vertical" style={{maxWidth:480}}>
      <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
      <Form.Item name="promo"><Input placeholder="Promotion code (optional)"/></Form.Item>
      <Form.Item><Button htmlType="submit" type="primary">Place Order & Pay (mock)</Button></Form.Item>
    </Form>
  )
}
