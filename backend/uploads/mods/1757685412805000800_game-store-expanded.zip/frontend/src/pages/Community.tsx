
import React from 'react'
import { fetchPosts, createPost, createComment } from '../api/client'
import { List, Form, Input, Button } from 'antd'

export default function Community(){
  const [list, setList] = React.useState<any[]>([])
  React.useEffect(()=>{ fetchPosts().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await createPost({userEmail:vals.email, title:vals.title, content:vals.content}); fetchPosts().then(d=>setList(d)) }
  return (
    <div>
      <Form onFinish={onFinish} layout="vertical">
        <Form.Item name="email" rules={[{required:true}]}> <Input placeholder="Your email" /> </Form.Item>
        <Form.Item name="title"> <Input placeholder="Post title" /> </Form.Item>
        <Form.Item name="content"> <Input.TextArea placeholder="Content" /> </Form.Item>
        <Form.Item><Button htmlType="submit" type="primary">Post</Button></Form.Item>
      </Form>
      <List dataSource={list} renderItem={p=> (<List.Item key={p.ID}><List.Item.Meta title={p.Title} description={p.Content} /></List.Item>)} />
    </div>
  )
}
