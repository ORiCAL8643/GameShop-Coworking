import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App'
import Home from './pages/Home'
import Requests from './pages/Requests'
import ManageGames from './pages/ManageGames'
import Workshop from './pages/Workshop'
import Reviews from './pages/Reviews'
import Promotions from './pages/Promotions'
import Refunds from './pages/Refunds'
import Community from './pages/Community'
import Payments from './pages/Payments'
import Reports from './pages/Reports'
import './index.css'
import 'antd/dist/reset.css'

const router = createBrowserRouter([
  { path: '/', element: <App />, children: [
    { index:true, element: <Home /> },
    { path: 'requests', element: <Requests /> },
    { path: 'manage-games', element: <ManageGames /> },
    { path: 'workshop', element: <Workshop /> },
    { path: 'reviews', element: <Reviews /> },
    { path: 'promotions', element: <Promotions /> },
    { path: 'refunds', element: <Refunds /> },
    { path: 'community', element: <Community /> },
    { path: 'payments', element: <Payments /> },
    { path: 'reports', element: <Reports /> },
  ] }
])

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
)
