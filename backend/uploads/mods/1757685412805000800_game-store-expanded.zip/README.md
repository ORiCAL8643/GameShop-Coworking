# Game Store - Expanded (Skeleton)

This is a runnable skeleton monorepo for a game store with 10 subsystems implemented as mocked/skeleton endpoints and frontend pages.

## Run backend
```
cd backend
go mod tidy
go run .
```

## Run frontend
```
cd frontend
npm install
npm run dev
```

Frontend dev server proxies `/api` to `http://localhost:8080`.

Notes: Authentication is mocked via headers `X-User-Email` and `X-User-Role`. Payment/file uploads are mocked for local development.
