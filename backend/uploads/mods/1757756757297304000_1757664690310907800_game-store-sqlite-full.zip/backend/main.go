package main

import (
    "game-store-backend/routes"
    "game-store-backend/seed"
    "game-store-backend/store"
    "log"
)

func main() {
    db, err := store.NewSQLite("app.db")
    if err != nil {
        log.Fatalf("failed to open db: %v", err)
    }

    // Auto-migrate entities
    if err := store.Migrate(db); err != nil {
        log.Fatalf("migrate error: %v", err)
    }

    // seed data (admin user + products)
    if err := seed.Seed(db); err != nil {
        log.Fatalf("seed error: %v", err)
    }

    r := routes.Setup(db)
    log.Println("Backend running on http://localhost:8080")
    r.Run(":8080")
}
