package store

import (
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func NewSQLite(path string) (*gorm.DB, error) {
    db, err := gorm.Open(sqlite.Open(path), &gorm.Config{})
    if err != nil {
        return nil, err
    }
    return db, nil
}

func Migrate(db *gorm.DB) error {
    return db.AutoMigrate(
        &entity.User{}, &entity.Role{},
        &entity.Product{}, &entity.ProductImage{}, &entity.Category{}, &entity.Platform{},
        &entity.Request{}, &entity.RequestComment{}, &entity.RequestStatus{}, &entity.RequestAttachment{},
        &entity.WorkshopItem{}, &entity.WorkshopFile{}, &entity.WorkshopLike{}, &entity.WorkshopReport{},
        &entity.Order{}, &entity.OrderItem{}, &entity.Payment{}, &entity.PaymentMethod{},
        &entity.Promotion{}, &entity.PromotionRule{}, &entity.PromotionUsage{}, &entity.PromotionTarget{},
        &entity.Refund{}, &entity.RefundLog{}, &entity.RefundReason{}, &entity.RefundTransaction{},
        &entity.Post{}, &entity.Comment{}, &entity.PostTag{}, &entity.PostReaction{},
        &entity.Review{}, &entity.ReviewVote{}, &entity.ReviewReport{}, &entity.ReviewMedia{},
        &entity.Report{}, &entity.ReportComment{}, &entity.ReportAssignment{}, &entity.ReportAttachment{},
    )
}
