package seed

import (
    "game-store-backend/entity"
    "golang.org/x/crypto/bcrypt"
    "gorm.io/gorm"
)

func Seed(db *gorm.DB) error {
    // admin user
    var count int64
    db.Model(&entity.User{}).Count(&count)
    if count == 0 {
        pw, _ := bcrypt.GenerateFromPassword([]byte("adminpass"), bcrypt.DefaultCost)
        admin := entity.User{Name: "Admin", Email: "admin@example.com", PasswordHash: string(pw), Role: "admin"}
        db.Create(&admin)
        userpw, _ := bcrypt.GenerateFromPassword([]byte("userpass"), bcrypt.DefaultCost)
        user := entity.User{Name: "Demo", Email: "user@example.com", PasswordHash: string(userpw), Role: "user"}
        db.Create(&user)
    }
    // other seeds (products, promotions)
    var pcount int64
    db.Model(&entity.Product{}).Count(&pcount)
    if pcount == 0 {
        products := []entity.Product{
            {Title: "Elden Ring", Slug: "elden-ring", Description: "Action RPG", Price: 59.99, PlatformID:1, CategoryID:1, Stock:20, Images: []entity.ProductImage{{URL: "https://placehold.co/600x400?text=Elden+Ring"}}},
            {Title: "Baldur's Gate 3", Slug: "baldurs-gate-3", Description: "CRPG", Price: 69.99, PlatformID:1, CategoryID:1, Stock:15, Images: []entity.ProductImage{{URL: "https://placehold.co/600x400?text=BG3"}}},
        }
        for _, p := range products { db.Create(&p) }
    }
    var promoCount int64
    db.Model(&entity.Promotion{}).Count(&promoCount)
    if promoCount == 0 {
        db.Create(&entity.Promotion{Code: "WELCOME10", DiscountPercent:10, Active:true})
    }
    return nil
}
