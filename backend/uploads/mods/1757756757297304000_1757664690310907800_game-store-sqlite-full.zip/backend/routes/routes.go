package routes

import (
    "github.com/gin-contrib/cors"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/controllers"
)

func Setup(db *gorm.DB) *gin.Engine {
    r := gin.Default()
    r.Use(cors.Default())

    // auth
    auth := r.Group("/api/auth")
    { auth.POST("/register", controllers.Register(db)); auth.POST("/login", controllers.Login(db)) }

    api := r.Group("/api")
    { 
        controllers.ProductRoutes(api.Group("/products"), db)
        controllers.RequestRoutes(api.Group("/requests"), db)
        controllers.WorkshopRoutes(api.Group("/workshop"), db)
        controllers.OrderRoutes(api.Group("/orders"), db)
        controllers.PaymentRoutes(api.Group("/payments"), db)
        controllers.PromotionRoutes(api.Group("/promotions"), db)
        controllers.RefundRoutes(api.Group("/refunds"), db)
        controllers.CommunityRoutes(api.Group("/community"), db)
        controllers.ReviewRoutes(api.Group("/reviews"), db)
        controllers.ReportRoutes(api.Group("/reports"), db)
    }

    return r
}
