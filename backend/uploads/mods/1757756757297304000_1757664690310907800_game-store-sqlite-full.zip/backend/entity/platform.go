package entity

import "gorm.io/gorm"

type Platform struct {
    gorm.Model
    Name string `json:"name"`
}
