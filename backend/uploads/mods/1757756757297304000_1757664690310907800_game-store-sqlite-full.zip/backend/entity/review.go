package entity

import "gorm.io/gorm"

type Review struct {
    gorm.Model
    ProductID uint `json:"productId"`
    UserEmail string `json:"userEmail"`
    Rating int `json:"rating"`
    Comment string `json:"comment"`
}
