package entity

import "gorm.io/gorm"

type ReportAttachment struct {
    gorm.Model
    ReportID uint `json:"reportId"`
    URL string `json:"url"`
}
