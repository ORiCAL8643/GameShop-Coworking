package entity

import "gorm.io/gorm"

type PostReaction struct {
    gorm.Model
    PostID uint `json:"postId"`
    UserEmail string `json:"userEmail"`
    Type string `json:"type"`
}
