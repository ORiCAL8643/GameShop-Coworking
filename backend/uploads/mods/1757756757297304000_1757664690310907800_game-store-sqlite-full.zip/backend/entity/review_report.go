package entity

import "gorm.io/gorm"

type ReviewReport struct {
    gorm.Model
    ReviewID uint `json:"reviewId"`
    UserEmail string `json:"userEmail"`
    Reason string `json:"reason"`
}
