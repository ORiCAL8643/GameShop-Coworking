package entity

import "gorm.io/gorm"

type PostTag struct {
    gorm.Model
    PostID uint `json:"postId"`
    Tag string `json:"tag"`
}
