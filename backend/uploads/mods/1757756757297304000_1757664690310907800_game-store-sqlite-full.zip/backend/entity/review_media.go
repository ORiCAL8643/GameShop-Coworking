package entity

import "gorm.io/gorm"

type ReviewMedia struct {
    gorm.Model
    ReviewID uint `json:"reviewId"`
    URL string `json:"url"`
}
