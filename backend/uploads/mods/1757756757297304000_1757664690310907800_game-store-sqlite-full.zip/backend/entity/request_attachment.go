package entity

import "gorm.io/gorm"

type RequestAttachment struct {
    gorm.Model
    RequestID uint `json:"requestId"`
    URL string `json:"url"`
}
