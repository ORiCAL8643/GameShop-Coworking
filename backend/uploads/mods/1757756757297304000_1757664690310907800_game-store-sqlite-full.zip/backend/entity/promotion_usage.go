package entity

import "gorm.io/gorm"

type PromotionUsage struct {
    gorm.Model
    PromotionID uint `json:"promotionId"`
    OrderID uint `json:"orderId"`
}
