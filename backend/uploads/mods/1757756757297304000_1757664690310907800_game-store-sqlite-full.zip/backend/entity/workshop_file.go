package entity

import "gorm.io/gorm"

type WorkshopFile struct {
    gorm.Model
    WorkshopItemID uint `json:"workshopItemId"`
    URL string `json:"url"`
}
