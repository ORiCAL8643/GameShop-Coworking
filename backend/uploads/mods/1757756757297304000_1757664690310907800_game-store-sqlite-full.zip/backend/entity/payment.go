package entity

import "gorm.io/gorm"

type Payment struct {
    gorm.Model
    OrderID uint `json:"orderId"`
    Amount float64 `json:"amount"`
    Provider string `json:"provider"`
    Status string `json:"status"` // initiated, succeeded, failed
}
