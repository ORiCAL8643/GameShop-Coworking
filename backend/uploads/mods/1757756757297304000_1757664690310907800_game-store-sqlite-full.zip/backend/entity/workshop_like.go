package entity

import "gorm.io/gorm"

type WorkshopLike struct {
    gorm.Model
    WorkshopItemID uint `json:"workshopItemId"`
    UserEmail string `json:"userEmail"`
}
