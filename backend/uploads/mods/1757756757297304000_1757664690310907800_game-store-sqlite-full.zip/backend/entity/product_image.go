package entity

import "gorm.io/gorm"

type ProductImage struct {
    gorm.Model
    ProductID uint `json:"productId"`
    URL string `json:"url"`
}
