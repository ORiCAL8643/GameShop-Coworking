package entity

import "gorm.io/gorm"

type PromotionRule struct {
    gorm.Model
    PromotionID uint `json:"promotionId"`
    MinTotal float64 `json:"minTotal"`
}
