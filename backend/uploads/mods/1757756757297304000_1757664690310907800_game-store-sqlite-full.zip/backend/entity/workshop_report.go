package entity

import "gorm.io/gorm"

type WorkshopReport struct {
    gorm.Model
    WorkshopItemID uint `json:"workshopItemId"`
    UserEmail string `json:"userEmail"`
    Reason string `json:"reason"`
}
