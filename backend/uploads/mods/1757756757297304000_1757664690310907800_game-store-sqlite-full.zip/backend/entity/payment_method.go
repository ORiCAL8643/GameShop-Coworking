package entity

import "gorm.io/gorm"

type PaymentMethod struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    Provider string `json:"provider"`
    Details string `json:"details"`
}
