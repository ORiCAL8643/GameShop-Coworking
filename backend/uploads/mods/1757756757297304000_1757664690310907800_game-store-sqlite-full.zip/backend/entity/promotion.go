package entity

import "gorm.io/gorm"

type Promotion struct {
    gorm.Model
    Code string `json:"code" gorm:"uniqueIndex"`
    DiscountPercent int `json:"discountPercent"`
    Active bool `json:"active"`
}
