package entity

import "gorm.io/gorm"

type RequestStatus struct {
    gorm.Model
    RequestID uint `json:"requestId"`
    Status string `json:"status"`
}
