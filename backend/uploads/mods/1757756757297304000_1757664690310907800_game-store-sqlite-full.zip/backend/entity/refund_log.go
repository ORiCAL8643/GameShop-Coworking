package entity

import "gorm.io/gorm"

type RefundLog struct {
    gorm.Model
    RefundID uint `json:"refundId"`
    Message string `json:"message"`
}
