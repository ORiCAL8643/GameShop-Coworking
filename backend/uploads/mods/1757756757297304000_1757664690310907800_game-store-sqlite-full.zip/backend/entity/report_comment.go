package entity

import "gorm.io/gorm"

type ReportComment struct {
    gorm.Model
    ReportID uint `json:"reportId"`
    UserEmail string `json:"userEmail"`
    Comment string `json:"comment"`
}
