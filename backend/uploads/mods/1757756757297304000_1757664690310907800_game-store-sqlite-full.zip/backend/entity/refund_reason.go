package entity

import "gorm.io/gorm"

type RefundReason struct {
    gorm.Model
    Code string `json:"code"`
    Description string `json:"description"`
}
