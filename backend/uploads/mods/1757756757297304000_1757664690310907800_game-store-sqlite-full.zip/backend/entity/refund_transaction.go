package entity

import "gorm.io/gorm"

type RefundTransaction struct {
    gorm.Model
    RefundID uint `json:"refundId"`
    Amount float64 `json:"amount"`
}
