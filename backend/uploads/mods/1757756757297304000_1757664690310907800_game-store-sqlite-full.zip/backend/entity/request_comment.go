package entity

import "gorm.io/gorm"

type RequestComment struct {
    gorm.Model
    RequestID uint `json:"requestId"`
    UserEmail string `json:"userEmail"`
    Comment string `json:"comment"`
}
