package entity

import "gorm.io/gorm"

type WorkshopItem struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    Title string `json:"title"`
    Description string `json:"description"`
    FileURL string `json:"fileUrl"`
}
