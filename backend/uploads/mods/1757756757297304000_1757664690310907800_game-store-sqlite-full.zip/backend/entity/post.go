package entity

import "gorm.io/gorm"

type Post struct {
    gorm.Model
    UserEmail string `json:"userEmail"`
    Title string `json:"title"`
    Content string `json:"content"`
    Comments []Comment `json:"comments" gorm:"foreignKey:PostID"`
}
