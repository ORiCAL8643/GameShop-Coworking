package entity

import "gorm.io/gorm"

type PromotionTarget struct {
    gorm.Model
    PromotionID uint `json:"promotionId"`
    ProductID uint `json:"productId"`
}
