package entity

import "gorm.io/gorm"

type Product struct {
    gorm.Model
    Title string `json:"title"`
    Slug string `json:"slug" gorm:"uniqueIndex"`
    Description string `json:"description"`
    Price float64 `json:"price"`
    PlatformID uint `json:"platformId"`
    CategoryID uint `json:"categoryId"`
    Stock int `json:"stock"`
    Images []ProductImage `json:"images" gorm:"foreignKey:ProductID"`
}
