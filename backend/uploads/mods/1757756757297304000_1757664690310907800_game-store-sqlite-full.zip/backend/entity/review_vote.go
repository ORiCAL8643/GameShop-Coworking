package entity

import "gorm.io/gorm"

type ReviewVote struct {
    gorm.Model
    ReviewID uint `json:"reviewId"`
    UserEmail string `json:"userEmail"`
    Vote int `json:"vote"`
}
