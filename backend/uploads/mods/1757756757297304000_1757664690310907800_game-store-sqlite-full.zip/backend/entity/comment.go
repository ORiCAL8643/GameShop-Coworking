package entity

import "gorm.io/gorm"

type Comment struct {
    gorm.Model
    PostID uint `json:"postId"`
    UserEmail string `json:"userEmail"`
    Content string `json:"content"`
}
