package entity

import "gorm.io/gorm"

type ReportAssignment struct {
    gorm.Model
    ReportID uint `json:"reportId"`
    AssignedTo string `json:"assignedTo"`
}
