package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func ReportRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var rp entity.Report; if err:=c.ShouldBindJSON(&rp); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; rp.Status = "open"; db.Create(&rp); c.JSON(http.StatusCreated, rp) })
    r.GET("/", func(c *gin.Context){ var list []entity.Report; db.Find(&list); c.JSON(http.StatusOK, list) })
}
