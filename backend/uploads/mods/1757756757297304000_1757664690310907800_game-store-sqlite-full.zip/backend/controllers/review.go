package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func ReviewRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var rv entity.Review; if err:=c.ShouldBindJSON(&rv); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&rv); c.JSON(http.StatusCreated, rv) })
    r.GET("/product/:productId", func(c *gin.Context){ var list []entity.Review; db.Where("product_id = ?", c.Param("productId")).Find(&list); c.JSON(http.StatusOK, list) })
}
