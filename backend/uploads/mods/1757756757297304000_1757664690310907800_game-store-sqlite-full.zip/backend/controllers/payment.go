package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func PaymentRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/mock", func(c *gin.Context){ var body struct{ OrderID uint `json:"orderId"` }; if err:=c.ShouldBindJSON(&body); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; pay := entity.Payment{OrderID: body.OrderID, Amount:0, Provider:"mock", Status:"succeeded"}; db.Create(&pay); var o entity.Order; if err:=db.First(&o, body.OrderID).Error; err==nil{ o.Status = "paid"; db.Save(&o) }; c.JSON(http.StatusOK, pay) })
}
