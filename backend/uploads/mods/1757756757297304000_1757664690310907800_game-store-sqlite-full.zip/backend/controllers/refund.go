package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func RefundRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var rf entity.Refund; if err:=c.ShouldBindJSON(&rf); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; rf.Status = "requested"; db.Create(&rf); c.JSON(http.StatusCreated, rf) })
    r.GET("/", func(c *gin.Context){ var list []entity.Refund; db.Find(&list); c.JSON(http.StatusOK, list) })
}
