package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func CommunityRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/posts", func(c *gin.Context){ var p entity.Post; if err:=c.ShouldBindJSON(&p); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&p); c.JSON(http.StatusCreated, p) })
    r.GET("/posts", func(c *gin.Context){ var list []entity.Post; db.Preload("Comments").Find(&list); c.JSON(http.StatusOK, list) })
    r.POST("/comments", func(c *gin.Context){ var cm entity.Comment; if err:=c.ShouldBindJSON(&cm); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&cm); c.JSON(http.StatusCreated, cm) })
}
