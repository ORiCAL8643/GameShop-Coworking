package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func WorkshopRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var w entity.WorkshopItem; if err:=c.ShouldBindJSON(&w); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&w); c.JSON(http.StatusCreated, w) })
    r.GET("/", func(c *gin.Context){ var list []entity.WorkshopItem; db.Find(&list); c.JSON(http.StatusOK, list) })
}
