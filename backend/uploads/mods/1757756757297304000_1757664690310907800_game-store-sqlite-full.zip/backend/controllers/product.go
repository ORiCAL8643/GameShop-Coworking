package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func ProductRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.GET("/", func(c *gin.Context){ var list []entity.Product; db.Preload("Images").Find(&list); c.JSON(http.StatusOK, list) })
    r.GET("/:id", func(c *gin.Context){ var p entity.Product; if err:=db.Preload("Images").First(&p, c.Param("id")).Error; err!=nil{c.JSON(http.StatusNotFound, gin.H{"error":"not found"});return}; c.JSON(http.StatusOK,p) })
    r.POST("/", func(c *gin.Context){ var p entity.Product; if err:=c.ShouldBindJSON(&p); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&p); c.JSON(http.StatusCreated,p) })
}
