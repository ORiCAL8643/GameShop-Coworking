package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func PromotionRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var p entity.Promotion; if err:=c.ShouldBindJSON(&p); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; db.Create(&p); c.JSON(http.StatusCreated, p) })
    r.GET("/", func(c *gin.Context){ var list []entity.Promotion; db.Find(&list); c.JSON(http.StatusOK, list) })
}
