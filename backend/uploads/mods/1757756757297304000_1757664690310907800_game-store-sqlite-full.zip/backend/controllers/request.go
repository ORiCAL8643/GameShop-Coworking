package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func RequestRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){ var req entity.Request; if err:=c.ShouldBindJSON(&req); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; req.Status="pending"; db.Create(&req); c.JSON(http.StatusCreated, req) })
    r.GET("/", func(c *gin.Context){ var list []entity.Request; db.Find(&list); c.JSON(http.StatusOK, list) })
    r.PUT("/:id/status", func(c *gin.Context){ var body struct{ Status string `json:"status"` }; if err:=c.ShouldBindJSON(&body); err!=nil{c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()});return}; var rentity entity.Request; if err:=db.First(&rentity, c.Param("id")).Error; err!=nil{c.JSON(http.StatusNotFound, gin.H{"error":"not found"});return}; rentity.Status=body.Status; db.Save(&rentity); c.JSON(http.StatusOK, rentity) })
}
