package controllers

import (
    "net/http"
    "time"

    "github.com/gin-gonic/gin"
    "golang.org/x/crypto/bcrypt"
    "gorm.io/gorm"
    "game-store-backend/entity"
    "github.com/golang-jwt/jwt/v5"
)

var jwtKey = []byte("demo-secret-key")

func Register(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        var body struct{ Name, Email, Password string }
        if err := c.ShouldBindJSON(&body); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()}); return }
        hash, _ := bcrypt.GenerateFromPassword([]byte(body.Password), bcrypt.DefaultCost)
        user := entity.User{Name: body.Name, Email: body.Email, PasswordHash: string(hash), Role: "user"}
        if err := db.Create(&user).Error; err != nil { c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()}); return }
        c.JSON(http.StatusCreated, gin.H{"id":user.ID, "email":user.Email})
    }
}

func Login(db *gorm.DB) gin.HandlerFunc {
    return func(c *gin.Context) {
        var body struct{ Email, Password string }
        if err := c.ShouldBindJSON(&body); err != nil { c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()}); return }
        var user entity.User
        if err := db.Where("email = ?", body.Email).First(&user).Error; err != nil { c.JSON(http.StatusUnauthorized, gin.H{"error":"invalid credentials"}); return }
        if err := bcrypt.CompareHashAndPassword([]byte(user.PasswordHash), []byte(body.Password)); err != nil { c.JSON(http.StatusUnauthorized, gin.H{"error":"invalid credentials"}); return }
        // create jwt
        claims := jwt.MapClaims{"sub": user.Email, "role": user.Role, "exp": time.Now().Add(time.Hour*24).Unix()}
        token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
        s, _ := token.SignedString(jwtKey)
        c.JSON(http.StatusOK, gin.H{"token": s, "email": user.Email, "role": user.Role})
    }
}

func MiddlewareJWT() gin.HandlerFunc {
    return func(c *gin.Context) {
        auth := c.GetHeader("Authorization")
        if auth == "" { c.Next(); return }
        var tokenStr string
        if len(auth) > 7 && auth[:7] == "Bearer " { tokenStr = auth[7:] }
        if tokenStr == "" { c.Next(); return }
        token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (interface{}, error){ return jwtKey, nil })
        if err == nil && token.Valid {
            if claims, ok := token.Claims.(jwt.MapClaims); ok {
                if sub, ok := claims["sub"].(string); ok { c.Set("userEmail", sub) }
                if role, ok := claims["role"].(string); ok { c.Set("userRole", role) }
            }
        }
        c.Next()
    }
}
