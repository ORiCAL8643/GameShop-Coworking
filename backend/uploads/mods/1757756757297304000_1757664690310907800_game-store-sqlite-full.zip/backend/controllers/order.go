package controllers

import (
    "net/http"
    "github.com/gin-gonic/gin"
    "gorm.io/gorm"
    "game-store-backend/entity"
)

func OrderRoutes(r *gin.RouterGroup, db *gorm.DB) {
    r.POST("/", func(c *gin.Context){
        var body struct{ UserEmail string `json:"userEmail"`; Items []struct{ ProductID uint `json:"productId"`; Quantity int `json:"quantity"` } `json:"items"`; PromotionCode string `json:"promotionCode"` }
        if err:=c.ShouldBindJSON(&body); err!=nil{ c.JSON(http.StatusBadRequest, gin.H{"error":err.Error()}); return }
        var items []entity.OrderItem
        var total float64
        for _, it := range body.Items {
            var p entity.Product
            if err := db.First(&p, it.ProductID).Error; err != nil { c.JSON(http.StatusBadRequest, gin.H{"error":"invalid product"}); return }
            if p.Stock < it.Quantity { c.JSON(http.StatusBadRequest, gin.H{"error":"insufficient stock"}); return }
            p.Stock -= it.Quantity; db.Save(&p)
            items = append(items, entity.OrderItem{ProductID:p.ID, Title:p.Title, Price:p.Price, Quantity:it.Quantity})
            total += p.Price * float64(it.Quantity)
        }
        order := entity.Order{UserEmail:body.UserEmail, Status:"pending", Total: total, Items: items}
        db.Create(&order)
        c.JSON(http.StatusCreated, order)
    })
    r.GET("/:id", func(c *gin.Context){ var o entity.Order; if err:=db.Preload("Items").First(&o, c.Param("id")).Error; err!=nil{c.JSON(http.StatusNotFound, gin.H{"error":"not found"}); return}; c.JSON(http.StatusOK, o) })
}
