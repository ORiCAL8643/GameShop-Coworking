# Game Store (SQLite Full)

This repository is a runnable local full-stack game store skeleton using **SQLite** as the primary database.

## Run backend

```bash
cd backend
go mod tidy
go run .
```

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

Default seeded users:
- admin@example.com / adminpass
- user@example.com / userpass

Auth: POST /api/auth/login -> { email, password } -> returns token. Set `Authorization: Bearer <token>` header for protected routes.

Notes: This is a developer local setup. Replace `jwt` secret and secure storage before production.
