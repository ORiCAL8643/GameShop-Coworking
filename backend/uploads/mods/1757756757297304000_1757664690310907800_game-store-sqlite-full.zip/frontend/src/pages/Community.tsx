
import React from 'react'
import { community } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Community(){ const [list,setList]=React.useState<any[]>([]); React.useEffect(()=>{ community.posts().then(d=>setList(d)) },[]); const onFinish=async(v:any)=>{ await community.createPost({userEmail:v.email,title:v.title,content:v.content}); community.posts().then(d=>setList(d)) } return (<div><Form onFinish={onFinish}><Form.Item name='email'><Input/></Form.Item><Form.Item name='title'><Input/></Form.Item><Form.Item name='content'><Input.TextArea/></Form.Item><Form.Item><Button htmlType='submit'>Post</Button></Form.Item></Form><List dataSource={list} renderItem={i=> (<List.Item key={i.ID}><List.Item.Meta title={i.Title} description={i.Content} /></List.Item>)} /></div>) }
