
import React from 'react'
import { Form, Input, Button, Table } from 'antd'
import { requests } from '../api/client'

export default function Requests(){
  const [list,setList]=React.useState<any[]>([])
  React.useEffect(()=>{ requests.list().then(d=>setList(d)) },[])
  const onFinish = async (vals:any)=>{ await requests.create({userEmail:vals.email, gameName:vals.game, reason:vals.reason}); requests.list().then(d=>setList(d)) }
  return (<div><Form onFinish={onFinish} layout="inline"><Form.Item name="email"><Input placeholder="email" /></Form.Item><Form.Item name="game"><Input placeholder="game"/></Form.Item><Form.Item name="reason"><Input placeholder="reason"/></Form.Item><Form.Item><Button htmlType="submit">Request</Button></Form.Item></Form><Table dataSource={list} rowKey="ID" columns={[{title:'Game',dataIndex:'GameName'},{title:'Status',dataIndex:'Status'}]} /></div>)
}
