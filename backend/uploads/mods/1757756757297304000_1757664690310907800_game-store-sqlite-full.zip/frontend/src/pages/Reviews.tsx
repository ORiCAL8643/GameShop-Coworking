
import React from 'react'
import { reviews } from '../api/client'
import { Form, Input, Button, InputNumber, List } from 'antd'

export default function Reviews(){ const [list,setList]=React.useState<any[]>([]); const [pid,setPid]=React.useState(1); React.useEffect(()=>{ reviews.list(pid).then(d=>setList(d)) },[pid]); const onFinish=async(v:any)=>{ await reviews.create({productId:pid,userEmail:v.email,rating:v.rating,comment:v.comment}); reviews.list(pid).then(d=>setList(d)) } return (<div><Form onFinish={onFinish} layout='inline'><Form.Item name='email'><Input/></Form.Item><Form.Item name='rating'><InputNumber min={1} max={5} defaultValue={5}/></Form.Item><Form.Item name='comment'><Input/></Form.Item><Form.Item><Button htmlType='submit'>Review</Button></Form.Item></Form><List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.UserEmail}: {i.Rating} — {i.Comment}</List.Item>)} /></div>) }
