import React from 'react'
import { Form, Input, Button, message } from 'antd'
import { auth } from '../api/client'

export default function Auth(){
  const onRegister = async (vals:any)=>{ try{ await auth.register({name:vals.name,email:vals.email,password:vals.password}); message.success('Registered') }catch(e:any){ message.error(e?.response?.data?.error || 'Error') } }
  const onLogin = async (vals:any)=>{ try{ const res = await auth.login({email:vals.email,password:vals.password}); localStorage.setItem('token', res.token); message.success('Logged in'); }catch(e:any){ message.error('Login failed') } }
  return (
    <div style={{display:'flex', gap:24}}>
      <Form onFinish={onRegister} style={{maxWidth:320}}>
        <h3>Register</h3>
        <Form.Item name="name" rules={[{required:true}]}><Input placeholder="Name"/></Form.Item>
        <Form.Item name="email" rules={[{required:true,type:'email'}]}><Input placeholder="Email"/></Form.Item>
        <Form.Item name="password" rules={[{required:true}]}><Input.Password placeholder="Password"/></Form.Item>
        <Form.Item><Button htmlType="submit">Register</Button></Form.Item>
      </Form>
      <Form onFinish={onLogin} style={{maxWidth:320}}>
        <h3>Login</h3>
        <Form.Item name="email" rules={[{required:true,type:'email'}]}><Input placeholder="Email"/></Form.Item>
        <Form.Item name="password" rules={[{required:true}]}><Input.Password placeholder="Password"/></Form.Item>
        <Form.Item><Button htmlType="submit">Login</Button></Form.Item>
      </Form>
    </div>
  )
}
