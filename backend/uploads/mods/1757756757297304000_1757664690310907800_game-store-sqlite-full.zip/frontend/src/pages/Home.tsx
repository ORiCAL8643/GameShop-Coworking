import React from 'react'
import { products } from '../api/client'
import { Row, Col, Card, Spin } from 'antd'

export default function Home(){
  const [loading,setLoading]=React.useState(true)
  const [list,setList]=React.useState<any[]>([])
  React.useEffect(()=>{ products.list().then(d=>setList(d)).finally(()=>setLoading(false)) },[])
  if(loading) return <Spin />
  return (
    <Row gutter={[16,16]}>
      {list.map(p=>(<Col key={p.ID} xs={24} sm={12} md={8}><Card title={p.Title}><img src={p.Images?.[0]?.URL} style={{width:'100%'}} alt={p.Title}/></Card></Col>))}
    </Row>
  )
}
