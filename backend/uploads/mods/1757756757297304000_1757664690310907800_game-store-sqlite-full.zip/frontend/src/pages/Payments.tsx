
import React from 'react'
import { orders, payments } from '../api/client'
import { Form, Input, Button } from 'antd'

export default function Payments(){ const onFinish=async(v:any)=>{ const order = await orders.create({userEmail:v.email, items:[{productId:1, quantity:1}], promotionCode:v.promo||''}); await payments.mock({orderId:order.ID}); alert('Order & paid: '+order.ID) } return (<Form onFinish={onFinish}><Form.Item name='email'><Input/></Form.Item><Form.Item name='promo'><Input/></Form.Item><Form.Item><Button htmlType='submit'>Place & Pay</Button></Form.Item></Form>) }
