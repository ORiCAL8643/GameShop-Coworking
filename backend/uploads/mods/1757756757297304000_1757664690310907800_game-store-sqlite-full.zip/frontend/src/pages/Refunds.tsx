
import React from 'react'
import { refunds } from '../api/client'
import { Form, Input, Button } from 'antd'

export default function Refunds(){ const onFinish=async(v:any)=>{ await refunds.create({orderId:parseInt(v.orderId),reason:v.reason}); alert('Requested') } return (<Form onFinish={onFinish}><Form.Item name='orderId'><Input/></Form.Item><Form.Item name='reason'><Input.TextArea/></Form.Item><Form.Item><Button htmlType='submit'>Request</Button></Form.Item></Form>) }
