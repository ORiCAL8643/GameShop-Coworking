
import React from 'react'
import { reports } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Reports(){ const [list,setList]=React.useState<any[]>([]); React.useEffect(()=>{ reports.list().then(d=>setList(d)) },[]); const onFinish=async(v:any)=>{ await reports.create({userEmail:v.email, category:v.category, message:v.message}); reports.list().then(d=>setList(d)) } return (<div><Form onFinish={onFinish}><Form.Item name='email'><Input/></Form.Item><Form.Item name='category'><Input/></Form.Item><Form.Item name='message'><Input.TextArea/></Form.Item><Form.Item><Button htmlType='submit'>Report</Button></Form.Item></Form><List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.Category}: {i.Message}</List.Item>)} /></div>) }
