
import React from 'react'
import { promotions } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Promotions(){ const [list,setList]=React.useState<any[]>([]); React.useEffect(()=>{ promotions.list().then(d=>setList(d)) },[]); const onFinish=async(v:any)=>{ await promotions.create({Code:v.code,DiscountPercent:parseInt(v.percent),Active:true}); promotions.list().then(d=>setList(d)) } return (<div><Form onFinish={onFinish} layout='inline'><Form.Item name='code'><Input/></Form.Item><Form.Item name='percent'><Input/></Form.Item><Form.Item><Button htmlType='submit'>Create</Button></Form.Item></Form><List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.Code} — {i.DiscountPercent}%</List.Item>)} /></div>) }
