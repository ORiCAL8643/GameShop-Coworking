
import React from 'react'
import { products } from '../api/client'
import { Table, Button, Modal, Form, Input, InputNumber } from 'antd'

export default function ManageGames(){
  const [list,setList]=React.useState<any[]>([])
  const [open,setOpen]=React.useState(false)
  React.useEffect(()=>{ products.list().then(d=>setList(d)) },[])
  const onFinish=async(vals:any)=>{ await products.create({Title:vals.title,Slug:vals.slug,Description:vals.description,Price:vals.price}); setOpen(false); products.list().then(d=>setList(d)) }
  return (<div><Button type='primary' onClick={()=>setOpen(true)}>Add</Button><Table dataSource={list} rowKey='ID' columns={[{title:'Title',dataIndex:'Title'},{title:'Price',dataIndex:'Price'}]} /><Modal open={open} onCancel={()=>setOpen(false)} footer={null}><Form onFinish={onFinish} layout='vertical'><Form.Item name='title' label='Title'><Input/></Form.Item><Form.Item name='slug' label='Slug'><Input/></Form.Item><Form.Item name='price' label='Price'><InputNumber/></Form.Item><Form.Item name='description' label='Description'><Input.TextArea/></Form.Item><Form.Item><Button htmlType='submit'>Create</Button></Form.Item></Form></Modal></div>)
}
