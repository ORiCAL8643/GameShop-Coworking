
import React from 'react'
import { workshop } from '../api/client'
import { Form, Input, Button, List } from 'antd'

export default function Workshop(){ const [list,setList]=React.useState<any[]>([]); React.useEffect(()=>{ workshop.list().then(d=>setList(d)) },[]); const onFinish=async(v:any)=>{ await workshop.create({userEmail:v.email,title:v.title,description:v.description,fileUrl:v.file}); workshop.list().then(d=>setList(d)) } return (<div><Form onFinish={onFinish} layout='inline'><Form.Item name='email'><Input/></Form.Item><Form.Item name='title'><Input/></Form.Item><Form.Item name='file'><Input/></Form.Item><Form.Item><Button htmlType='submit'>Upload</Button></Form.Item></Form><List dataSource={list} renderItem={i=> (<List.Item key={i.ID}>{i.Title} - {i.UserEmail}</List.Item>)} /></div>) }
