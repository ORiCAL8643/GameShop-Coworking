import axios from 'axios'
const api = axios.create({ baseURL: '/api' })
export default api
export const auth = { register: (b:any)=>api.post('/auth/register', b).then(r=>r.data), login:(b:any)=>api.post('/auth/login', b).then(r=>r.data) }
export const products = { list:()=>api.get('/products/').then(r=>r.data), get:(id:any)=>api.get(`/products/${id}`).then(r=>r.data), create:(p:any)=>api.post('/products', p).then(r=>r.data) }
export const requests = { list:()=>api.get('/requests/').then(r=>r.data), create:(b:any)=>api.post('/requests', b).then(r=>r.data), updateStatus:(id,st)=>api.put(`/requests/${id}/status`, {status:st}).then(r=>r.data) }
export const workshop = { list:()=>api.get('/workshop/').then(r=>r.data), create:(b:any)=>api.post('/workshop', b).then(r=>r.data) }
export const orders = { create:(b:any)=>api.post('/orders', b).then(r=>r.data), get:(id)=>api.get(`/orders/${id}`).then(r=>r.data) }
export const payments = { mock:(b:any)=>api.post('/payments/mock', b).then(r=>r.data) }
export const promotions = { list:()=>api.get('/promotions/').then(r=>r.data), create:(b:any)=>api.post('/promotions', b).then(r=>r.data) }
export const refunds = { create:(b:any)=>api.post('/refunds', b).then(r=>r.data), list:()=>api.get('/refunds').then(r=>r.data) }
export const community = { posts:()=>api.get('/community/posts').then(r=>r.data), createPost:(b:any)=>api.post('/community/posts', b).then(r=>r.data), createComment:(b:any)=>api.post('/community/comments', b).then(r=>r.data) }
export const reviews = { list:(pid:any)=>api.get(`/reviews/product/${pid}`).then(r=>r.data), create:(b:any)=>api.post('/reviews', b).then(r=>r.data) }
export const reports = { list:()=>api.get('/reports').then(r=>r.data), create:(b:any)=>api.post('/reports', b).then(r=>r.data) }
