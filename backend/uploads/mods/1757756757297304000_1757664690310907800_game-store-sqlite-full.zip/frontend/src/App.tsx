import React from 'react'
import { Layout, Menu } from 'antd'
import { Link, Outlet } from 'react-router-dom'

export default function App(){
  return (
    <Layout style={{minHeight:'100vh'}}>
      <Layout.Header style={{display:'flex', alignItems:'center'}}>
        <div style={{color:'white', fontWeight:700, marginRight:24}}>🎮 Game Store</div>
        <Menu theme="dark" mode="horizontal" selectable={false} items={[
          {key:'home', label:<Link to="/">Home</Link>}, {key:'auth', label:<Link to="/auth">Auth</Link>},
          {key:'requests', label:<Link to="/requests">Requests</Link>}, {key:'manage', label:<Link to="/manage-games">Manage</Link>},
          {key:'workshop', label:<Link to="/workshop">Workshop</Link>}, {key:'community', label:<Link to="/community">Community</Link>},
          {key:'reviews', label:<Link to="/reviews">Reviews</Link>}, {key:'promos', label:<Link to="/promotions">Promotions</Link>},
          {key:'refunds', label:<Link to="/refunds">Refunds</Link>}, {key:'payments', label:<Link to="/payments">Payments</Link>},
          {key:'reports', label:<Link to="/reports">Reports</Link>},
        ]}/>
      </Layout.Header>
      <Layout.Content style={{padding:24}}><Outlet/></Layout.Content>
      <Layout.Footer style={{textAlign:'center'}}>Game Store © {new Date().getFullYear()}</Layout.Footer>
    </Layout>
  )
}
